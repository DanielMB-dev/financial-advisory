---
name: supabase-rls-patterns
description: This skill should be used when designing and implementing Row Level Security (RLS) policies for Supabase databases, particularly for financial applications. Use this skill when creating data access patterns, securing user data, implementing multi-tenant architectures, designing policies for CRUD operations, and ensuring proper data isolation between users. The skill provides patterns for RLS policy design optimized for financial use cases including transactions, accounts, and sensitive financial data.
---

# Supabase RLS Patterns

## Overview

Provide comprehensive patterns for designing and implementing Row Level Security policies in Supabase, with specific focus on financial application requirements where data isolation and security are critical. Cover policy patterns for user-scoped data, shared data, and complex access control scenarios.

## When to Use This Skill

Use this skill when:
- Designing RLS policies for new database tables
- Implementing data isolation for multi-tenant architectures
- Securing financial data (transactions, accounts, balances)
- Creating policies for different CRUD operations
- Troubleshooting RLS policy performance issues
- Auditing existing RLS implementations
- Implementing role-based access control with RLS
- Designing policies for shared resources (categories, tags)

## Official Documentation References

- **Supabase RLS Overview**: https://supabase.com/docs/guides/auth/row-level-security
- **PostgreSQL RLS Documentation**: https://www.postgresql.org/docs/current/ddl-rowsecurity.html
- **Supabase Auth Helpers**: https://supabase.com/docs/guides/auth/server-side/overview
- **Policy Examples**: https://supabase.com/docs/guides/database/postgres/row-level-security
- **Performance Best Practices**: https://supabase.com/docs/guides/database/postgres/row-level-security#performance

## Core RLS Patterns

### 1. User-Scoped Data (Most Common)

For tables where each row belongs to a specific user:

```sql
-- Enable RLS
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

-- Users can only see their own transactions
CREATE POLICY "Users view own transactions"
  ON transactions FOR SELECT
  USING (auth.uid() = user_id);

-- Users can only insert their own transactions
CREATE POLICY "Users insert own transactions"
  ON transactions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Users can only update their own transactions
CREATE POLICY "Users update own transactions"
  ON transactions FOR UPDATE
  USING (auth.uid() = user_id);

-- Users can only delete their own transactions
CREATE POLICY "Users delete own transactions"
  ON transactions FOR DELETE
  USING (auth.uid() = user_id);
```

### 2. Shared Reference Data

For lookup tables shared across users (categories, tags):

```sql
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Everyone can read categories
CREATE POLICY "Anyone can view categories"
  ON categories FOR SELECT
  USING (true);

-- Only authenticated users can create categories
CREATE POLICY "Authenticated users create categories"
  ON categories FOR INSERT
  WITH CHECK (auth.role() = 'authenticated');
```

### 3. Financial Data with Decimal Precision

Ensure policies don't interfere with financial calculations:

```sql
CREATE POLICY "Users view own account balances"
  ON account_balances FOR SELECT
  USING (auth.uid() = user_id);

-- Index for performance
CREATE INDEX idx_account_balances_user_id
  ON account_balances(user_id)
  WHERE deleted_at IS NULL;
```

### 4. Soft Delete Pattern

Respect soft deletes in policies:

```sql
CREATE POLICY "Users view active transactions"
  ON transactions FOR SELECT
  USING (
    auth.uid() = user_id
    AND deleted_at IS NULL
  );
```

### 5. Role-Based Access Control

Implement different access levels:

```sql
CREATE POLICY "Admins see all transactions"
  ON transactions FOR SELECT
  USING (
    auth.jwt() ->> 'role' = 'admin'
    OR auth.uid() = user_id
  );
```

## Performance Optimization

### Index Strategy

Always create indexes on columns used in RLS policies:

```sql
-- User ID index
CREATE INDEX idx_table_user_id ON table_name(user_id);

-- Composite index for common queries
CREATE INDEX idx_table_user_date
  ON table_name(user_id, created_at DESC);

-- Partial index for soft deletes
CREATE INDEX idx_table_active
  ON table_name(user_id)
  WHERE deleted_at IS NULL;
```

### Policy Testing

Test policies with different users:

```sql
-- Set session to specific user
SET request.jwt.claim.sub = 'user-uuid';

-- Run query to test policy
SELECT * FROM transactions;

-- Reset
RESET request.jwt.claim.sub;
```

## Security Best Practices

1. **Always enable RLS** on user-facing tables
2. **Use `auth.uid()` not `current_user`** for user identification
3. **Test policies** with different user scenarios
4. **Create separate policies** for each operation (SELECT, INSERT, UPDATE, DELETE)
5. **Use `USING` clause** for row visibility
6. **Use `WITH CHECK` clause** for data modification constraints
7. **Avoid complex joins** in policies for performance
8. **Create indexes** on policy columns
9. **Audit policies regularly** for security gaps
10. **Document policy decisions** in migration comments

## Resources

### references/

- **financial-rls-patterns.md** - Complete RLS patterns for financial tables (transactions, accounts, budgets)
- **policy-testing-guide.md** - Methods and tools for testing RLS policies
- **performance-optimization.md** - Index strategies and query optimization for RLS
- **troubleshooting.md** - Common RLS issues and solutions

Load these references when implementing specific patterns or troubleshooting policy issues.

## Common Patterns for Financial Apps

See `references/financial-rls-patterns.md` for detailed implementations of:

- Transaction tables with multi-currency support
- Account balance tables with audit trails
- Budget tables with sharing capabilities
- Category tables with user-specific and shared entries
- Recurring transaction templates
- Report tables with caching
