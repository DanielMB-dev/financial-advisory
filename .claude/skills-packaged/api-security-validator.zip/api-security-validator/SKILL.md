---
name: api-security-validator
description: This skill should be used when validating API endpoint security following OWASP guidelines and Supabase security best practices. Use this skill when auditing Next.js API routes, validating input sanitization, implementing rate limiting, checking authentication/authorization logic, preventing common vulnerabilities (SQL injection, XSS, CSRF), and ensuring secure API design patterns. The skill focuses on financial application security where data protection is critical.
---

# API Security Validator

## Overview

Provide comprehensive security validation for Next.js API routes and Supabase integrations, following OWASP Top 10 guidelines and industry best practices for financial applications. Focus on preventing common vulnerabilities and implementing defense-in-depth security strategies.

## When to Use This Skill

Use this skill when:
- Auditing existing API endpoints for security vulnerabilities
- Reviewing new API route implementations before deployment
- Implementing security measures for financial data endpoints
- Validating authentication and authorization logic
- Setting up input validation and sanitization
- Implementing rate limiting and DDoS protection
- Checking for OWASP Top 10 vulnerabilities
- Conducting security code reviews
- Preparing for security audits or penetration testing

## Official Documentation References

- **OWASP Top 10**: https://owasp.org/www-project-top-ten/
- **OWASP API Security Top 10**: https://owasp.org/www-project-api-security/
- **Next.js Security**: https://nextjs.org/docs/app/building-your-application/configuring/security
- **Supabase Security**: https://supabase.com/docs/guides/platform/going-into-prod#security
- **Zod Validation**: https://zod.dev/
- **Rate Limiting**: https://github.com/vercel/next.js/tree/canary/examples/api-routes-rate-limit

## Security Checklist for API Routes

### 1. Authentication & Authorization

```typescript
// ✅ GOOD: Always verify authentication
import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  const supabase = createClient()

  // Verify user is authenticated
  const { data: { user }, error } = await supabase.auth.getUser()

  if (error || !user) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    )
  }

  // Verify user owns the resource
  const { id } = await request.json()
  const { data } = await supabase
    .from('transactions')
    .select('user_id')
    .eq('id', id)
    .single()

  if (data?.user_id !== user.id) {
    return NextResponse.json(
      { error: 'Forbidden' },
      { status: 403 }
    )
  }

  // Proceed with authorized request
}

// ❌ BAD: No authentication check
export async function GET(request: NextRequest) {
  const { id } = await request.json()
  // Direct database access without auth check
}
```

### 2. Input Validation & Sanitization

```typescript
import { z } from 'zod'

// ✅ GOOD: Strict validation with Zod
const transactionSchema = z.object({
  amount: z.number().positive().max(1000000),
  categoryId: z.string().uuid(),
  date: z.coerce.date().max(new Date()),
  description: z.string().max(500).optional()
})

export async function POST(request: NextRequest) {
  const body = await request.json()

  // Validate input
  const result = transactionSchema.safeParse(body)

  if (!result.success) {
    return NextResponse.json(
      { error: 'Invalid input', details: result.error.errors },
      { status: 400 }
    )
  }

  // Use validated data
  const validData = result.data
}

// ❌ BAD: No validation
export async function POST(request: NextRequest) {
  const body = await request.json()
  // Directly use unvalidated input
  await supabase.from('transactions').insert(body)
}
```

### 3. Rate Limiting

```typescript
// ✅ GOOD: Implement rate limiting
import { Ratelimit } from '@upstash/ratelimit'
import { Redis } from '@upstash/redis'

const ratelimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(10, '10 s'),
  analytics: true
})

export async function POST(request: NextRequest) {
  const ip = request.ip ?? '127.0.0.1'
  const { success } = await ratelimit.limit(ip)

  if (!success) {
    return NextResponse.json(
      { error: 'Too many requests' },
      { status: 429 }
    )
  }

  // Process request
}
```

### 4. Error Handling

```typescript
// ✅ GOOD: Sanitize error messages
export async function POST(request: NextRequest) {
  try {
    // Business logic
  } catch (error) {
    // Log full error server-side
    console.error('Transaction error:', error)

    // Return sanitized error to client
    return NextResponse.json(
      { error: 'Failed to process transaction' },
      { status: 500 }
    )
  }
}

// ❌ BAD: Expose internal errors
export async function POST(request: NextRequest) {
  try {
    // Business logic
  } catch (error) {
    // Never expose stack traces or database errors
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
```

### 5. CORS Configuration

```typescript
// middleware.ts
export function middleware(request: NextRequest) {
  const response = NextResponse.next()

  // Set strict CORS headers
  response.headers.set('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGIN!)
  response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE')
  response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization')

  return response
}
```

### 6. SQL Injection Prevention

```typescript
// ✅ GOOD: Use Supabase client (parameterized queries)
const { data } = await supabase
  .from('transactions')
  .select('*')
  .eq('user_id', userId)
  .eq('category_id', categoryId)

// ✅ GOOD: Use RLS policies for defense-in-depth
// Even if there's a bug, RLS prevents unauthorized access

// ❌ BAD: Raw SQL without parameterization
const query = `SELECT * FROM transactions WHERE user_id = '${userId}'`
```

### 7. XSS Prevention

```typescript
// ✅ GOOD: React auto-escapes by default
<div>{transaction.description}</div>

// ❌ BAD: Using dangerouslySetInnerHTML
<div dangerouslySetInnerHTML={{ __html: transaction.description }} />

// ✅ GOOD: Sanitize if HTML is needed
import DOMPurify from 'isomorphic-dompurify'
const clean = DOMPurify.sanitize(html)
```

### 8. CSRF Protection

```typescript
// Next.js API routes are protected by default with SameSite cookies
// Ensure cookies are configured properly:

// lib/supabase/server.ts
cookies: {
  set(name: string, value: string, options: CookieOptions) {
    cookieStore.set({
      name,
      value,
      ...options,
      sameSite: 'lax', // CSRF protection
      secure: process.env.NODE_ENV === 'production',
      httpOnly: true
    })
  }
}
```

## OWASP Top 10 API Security Checklist

- [ ] **API1: Broken Object Level Authorization** - Verify resource ownership
- [ ] **API2: Broken Authentication** - Implement proper JWT validation
- [ ] **API3: Broken Object Property Level Authorization** - Control exposed fields
- [ ] **API4: Unrestricted Resource Consumption** - Implement rate limiting
- [ ] **API5: Broken Function Level Authorization** - Check permissions per endpoint
- [ ] **API6: Unrestricted Access to Sensitive Business Flows** - Protect critical operations
- [ ] **API7: Server Side Request Forgery** - Validate URLs and IPs
- [ ] **API8: Security Misconfiguration** - Review CORS, headers, error messages
- [ ] **API9: Improper Inventory Management** - Document all endpoints
- [ ] **API10: Unsafe Consumption of APIs** - Validate external API responses

## Security Headers

Configure in `next.config.js`:

```javascript
const securityHeaders = [
  {
    key: 'X-DNS-Prefetch-Control',
    value: 'on'
  },
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=63072000; includeSubDomains; preload'
  },
  {
    key: 'X-Frame-Options',
    value: 'SAMEORIGIN'
  },
  {
    key: 'X-Content-Type-Options',
    value: 'nosniff'
  },
  {
    key: 'X-XSS-Protection',
    value: '1; mode=block'
  },
  {
    key: 'Referrer-Policy',
    value: 'origin-when-cross-origin'
  },
  {
    key: 'Permissions-Policy',
    value: 'camera=(), microphone=(), geolocation=()'
  }
]

module.exports = {
  async headers() {
    return [
      {
        source: '/:path*',
        headers: securityHeaders
      }
    ]
  }
}
```

## Resources

### references/

- **owasp-checklist.md** - Complete OWASP Top 10 checklist with examples
- **common-vulnerabilities.md** - Patterns for preventing common vulnerabilities
- **security-testing-guide.md** - Methods for testing API security
- **incident-response.md** - Procedures for handling security incidents

Load these references when conducting security audits or implementing security measures.

## Best Practices Summary

1. **Always validate input** with Zod or similar validation library
2. **Implement authentication** on all non-public endpoints
3. **Verify authorization** for resource access
4. **Use RLS policies** as a second layer of defense
5. **Implement rate limiting** on all endpoints
6. **Sanitize error messages** - never expose internal details
7. **Set security headers** in production
8. **Log security events** for audit trails
9. **Use HTTPS** in production
10. **Keep dependencies updated** - run `npm audit` regularly
