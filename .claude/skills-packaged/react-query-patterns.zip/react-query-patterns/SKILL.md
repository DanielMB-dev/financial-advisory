---
name: react-query-patterns
description: This skill should be used when implementing TanStack Query (React Query) patterns for data fetching, caching, and state management. Use this skill when setting up query hooks, implementing mutation hooks with optimistic updates, configuring cache invalidation strategies, handling loading and error states, implementing pagination and infinite queries, and optimizing React Query performance. The skill focuses on React Query v5 patterns for financial applications where data consistency and real-time updates are important.
---

# React Query Patterns

## Overview

Provide comprehensive patterns for implementing TanStack Query (React Query) v5 in React applications with focus on efficient caching strategies, optimistic updates, cache invalidation, and performance optimization for financial data synchronization.

## When to Use This Skill

Use this skill when:
- Setting up React Query in a Next.js application
- Creating query hooks for data fetching
- Implementing mutation hooks with cache updates
- Configuring optimistic updates for better UX
- Designing cache invalidation strategies
- Implementing pagination or infinite scroll
- Handling loading and error states
- Optimizing query performance
- Implementing dependent queries
- Setting up prefetching strategies

## Official Documentation References

- **TanStack Query (React Query) v5**: https://tanstack.com/query/latest
- **React Query Quickstart**: https://tanstack.com/query/latest/docs/framework/react/quick-start
- **Mutations**: https://tanstack.com/query/latest/docs/framework/react/guides/mutations
- **Optimistic Updates**: https://tanstack.com/query/latest/docs/framework/react/guides/optimistic-updates
- **Query Invalidation**: https://tanstack.com/query/latest/docs/framework/react/guides/query-invalidation
- **React Query DevTools**: https://tanstack.com/query/latest/docs/framework/react/devtools

## Setup

### 1. Installation

```bash
npm install @tanstack/react-query @tanstack/react-query-devtools
```

### 2. QueryClient Configuration

```typescript
// app/providers.tsx
'use client'

import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'
import { useState } from 'react'

export function Providers({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 60 * 1000, // 1 minute
            gcTime: 5 * 60 * 1000, // 5 minutes (formerly cacheTime)
            retry: 1,
            refetchOnWindowFocus: false
          },
          mutations: {
            retry: 0
          }
        }
      })
  )

  return (
    <QueryClientProvider client={queryClient}>
      {children}
      <ReactQueryDevtools initialIsOpen={false} />
    </QueryClientProvider>
  )
}
```

## Core Patterns

### 1. Query Hooks

```typescript
// hooks/queries/useTransactionsQuery.ts
import { useQuery } from '@tanstack/react-query'
import { transactionService } from '@/services/transactionService'

export function useTransactionsQuery(userId: string) {
  return useQuery({
    queryKey: ['transactions', userId],
    queryFn: () => transactionService.getAll(userId),
    enabled: !!userId, // Only run query if userId exists
    staleTime: 30 * 1000 // 30 seconds
  })
}

// Usage in component
function TransactionsList() {
  const { data, isLoading, isError, error } = useTransactionsQuery(userId)

  if (isLoading) return <Skeleton />
  if (isError) return <Error message={error.message} />
  if (!data) return null

  return <TransactionList transactions={data} />
}
```

### 2. Mutation Hooks

```typescript
// hooks/mutations/useCreateTransactionMutation.ts
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { transactionService } from '@/services/transactionService'
import type { CreateTransactionInput, Transaction } from '@/types'

export function useCreateTransactionMutation() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (input: CreateTransactionInput) =>
      transactionService.create(input),

    onSuccess: (newTransaction, variables) => {
      // Invalidate and refetch
      queryClient.invalidateQueries({
        queryKey: ['transactions', variables.userId]
      })

      // Also invalidate related queries
      queryClient.invalidateQueries({
        queryKey: ['account-balance', variables.accountId]
      })
    },

    onError: (error) => {
      console.error('Failed to create transaction:', error)
      // Toast notification here
    }
  })
}

// Usage with standardized return
export function useCreateTransaction() {
  const mutation = useCreateTransactionMutation()

  return {
    createTransaction: mutation.mutate,
    createTransactionAsync: mutation.mutateAsync,
    isLoading: mutation.isPending,
    isError: mutation.isError,
    error: mutation.error,
    isSuccess: mutation.isSuccess
  }
}
```

### 3. Optimistic Updates

```typescript
// hooks/mutations/useUpdateTransactionMutation.ts
import { useMutation, useQueryClient } from '@tanstack/react-query'

export function useUpdateTransactionMutation() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Transaction> }) =>
      transactionService.update(id, data),

    onMutate: async ({ id, data }) => {
      // Cancel outgoing refetches
      await queryClient.cancelQueries({
        queryKey: ['transactions']
      })

      // Snapshot previous value
      const previousTransactions = queryClient.getQueryData<Transaction[]>([
        'transactions',
        data.userId
      ])

      // Optimistically update
      queryClient.setQueryData<Transaction[]>(
        ['transactions', data.userId],
        (old) =>
          old?.map((transaction) =>
            transaction.id === id ? { ...transaction, ...data } : transaction
          ) ?? []
      )

      // Return context with snapshot
      return { previousTransactions }
    },

    onError: (error, variables, context) => {
      // Rollback on error
      if (context?.previousTransactions) {
        queryClient.setQueryData(
          ['transactions', variables.data.userId],
          context.previousTransactions
        )
      }
    },

    onSettled: (data, error, variables) => {
      // Always refetch after error or success
      queryClient.invalidateQueries({
        queryKey: ['transactions', variables.data.userId]
      })
    }
  })
}
```

### 4. Dependent Queries

```typescript
// First query
const { data: user } = useQuery({
  queryKey: ['user'],
  queryFn: getUser
})

// Second query depends on first
const { data: transactions } = useQuery({
  queryKey: ['transactions', user?.id],
  queryFn: () => getTransactions(user!.id),
  enabled: !!user?.id // Only run if user exists
})
```

### 5. Pagination

```typescript
// hooks/queries/useTransactionsPaginated.ts
import { useQuery } from '@tanstack/react-query'

export function useTransactionsPaginated(userId: string, page: number) {
  return useQuery({
    queryKey: ['transactions', userId, page],
    queryFn: () => transactionService.getPage(userId, page),
    placeholderData: (previousData) => previousData, // Keep previous data while loading
    staleTime: 30 * 1000
  })
}

// Usage
function TransactionsPaginated() {
  const [page, setPage] = useState(1)
  const { data, isLoading, isPlaceholderData } = useTransactionsPaginated(
    userId,
    page
  )

  return (
    <div>
      <TransactionList transactions={data?.transactions} />
      <div>
        <button
          onClick={() => setPage((old) => Math.max(old - 1, 1))}
          disabled={page === 1}
        >
          Previous
        </button>
        <button
          onClick={() => setPage((old) => old + 1)}
          disabled={isPlaceholderData || !data?.hasMore}
        >
          Next
        </button>
      </div>
    </div>
  )
}
```

### 6. Infinite Queries

```typescript
// hooks/queries/useTransactionsInfinite.ts
import { useInfiniteQuery } from '@tanstack/react-query'

export function useTransactionsInfinite(userId: string) {
  return useInfiniteQuery({
    queryKey: ['transactions', userId, 'infinite'],
    queryFn: ({ pageParam }) =>
      transactionService.getPage(userId, pageParam),
    initialPageParam: 1,
    getNextPageParam: (lastPage, allPages) =>
      lastPage.hasMore ? allPages.length + 1 : undefined,
    getPreviousPageParam: (firstPage, allPages) =>
      allPages.length > 1 ? allPages.length - 1 : undefined
  })
}

// Usage
function TransactionsInfiniteScroll() {
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage
  } = useTransactionsInfinite(userId)

  return (
    <div>
      {data?.pages.map((page) =>
        page.transactions.map((transaction) => (
          <TransactionItem key={transaction.id} transaction={transaction} />
        ))
      )}
      <button
        onClick={() => fetchNextPage()}
        disabled={!hasNextPage || isFetchingNextPage}
      >
        {isFetchingNextPage ? 'Loading...' : 'Load More'}
      </button>
    </div>
  )
}
```

### 7. Prefetching

```typescript
// Prefetch on hover
function TransactionLink({ id }: { id: string }) {
  const queryClient = useQueryClient()

  const prefetch = () => {
    queryClient.prefetchQuery({
      queryKey: ['transaction', id],
      queryFn: () => transactionService.getById(id),
      staleTime: 60 * 1000
    })
  }

  return (
    <Link href={`/transactions/${id}`} onMouseEnter={prefetch}>
      View Transaction
    </Link>
  )
}
```

### 8. Cache Manipulation

```typescript
// Manually set cache
queryClient.setQueryData<Transaction[]>(
  ['transactions', userId],
  (old) => [...(old ?? []), newTransaction]
)

// Get cache data
const cachedData = queryClient.getQueryData<Transaction[]>([
  'transactions',
  userId
])

// Invalidate specific query
queryClient.invalidateQueries({
  queryKey: ['transactions', userId]
})

// Invalidate all transactions queries
queryClient.invalidateQueries({
  queryKey: ['transactions']
})

// Remove query from cache
queryClient.removeQueries({
  queryKey: ['transactions', userId]
})
```

## Advanced Patterns

### 1. Global Error Handling

```typescript
// app/providers.tsx
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      onError: (error) => {
        toast.error(error.message)
        // Log to error tracking service
        Sentry.captureException(error)
      }
    },
    mutations: {
      onError: (error) => {
        toast.error(error.message)
        Sentry.captureException(error)
      }
    }
  }
})
```

### 2. Selective Invalidation

```typescript
// Only invalidate stale queries
queryClient.invalidateQueries({
  queryKey: ['transactions'],
  refetchType: 'active' // Only refetch active queries
})

// Invalidate without refetching
queryClient.invalidateQueries({
  queryKey: ['transactions'],
  refetchType: 'none'
})
```

### 3. Polling

```typescript
// Auto-refresh every 30 seconds
const { data } = useQuery({
  queryKey: ['balance'],
  queryFn: getBalance,
  refetchInterval: 30 * 1000
})

// Conditional polling
const { data } = useQuery({
  queryKey: ['balance'],
  queryFn: getBalance,
  refetchInterval: (query) => {
    // Stop polling if error
    return query.state.error ? false : 30 * 1000
  }
})
```

## Performance Optimization

### 1. Structural Sharing

React Query automatically uses structural sharing to optimize re-renders:

```typescript
// Shallow comparison of query results
// Only re-renders if actual data changes
const { data } = useQuery({
  queryKey: ['transactions'],
  queryFn: getTransactions
  // Structural sharing is enabled by default
})
```

### 2. Select Option

```typescript
// Transform data without causing unnecessary re-renders
const { data: transactionIds } = useQuery({
  queryKey: ['transactions'],
  queryFn: getTransactions,
  select: (transactions) => transactions.map((t) => t.id)
  // Only re-renders if IDs array changes
})
```

### 3. Placeholder Data

```typescript
// Show stale data while refetching
const { data } = useQuery({
  queryKey: ['transactions', page],
  queryFn: () => getTransactions(page),
  placeholderData: (previousData) => previousData
})
```

## Best Practices

1. **Use descriptive queryKeys** - Include all variables used in queryFn
2. **Set appropriate staleTime** - Balance freshness vs performance
3. **Implement optimistic updates** for better UX
4. **Always handle loading and error states**
5. **Use enabled option** for dependent queries
6. **Invalidate related queries** after mutations
7. **Prefetch data** on user interaction hints
8. **Use React Query DevTools** during development
9. **Configure global defaults** in QueryClient
10. **Implement error boundaries** for query errors

## Resources

### references/

- **query-patterns.md** - Advanced query patterns and configurations
- **mutation-patterns.md** - Mutation strategies and optimistic updates
- **cache-strategies.md** - Cache invalidation and management patterns
- **performance-tips.md** - Optimization techniques for React Query

Load these references when implementing complex query patterns or optimizing performance.

## Common Query Keys Pattern

```typescript
// Define query keys factory
export const queryKeys = {
  transactions: {
    all: ['transactions'] as const,
    lists: () => [...queryKeys.transactions.all, 'list'] as const,
    list: (userId: string) => [...queryKeys.transactions.lists(), userId] as const,
    details: () => [...queryKeys.transactions.all, 'detail'] as const,
    detail: (id: string) => [...queryKeys.transactions.details(), id] as const
  },
  accounts: {
    all: ['accounts'] as const,
    lists: () => [...queryKeys.accounts.all, 'list'] as const,
    list: (userId: string) => [...queryKeys.accounts.lists(), userId] as const
  }
}

// Usage
useQuery({
  queryKey: queryKeys.transactions.list(userId),
  queryFn: () => getTransactions(userId)
})

// Invalidate all transaction queries
queryClient.invalidateQueries({
  queryKey: queryKeys.transactions.all
})

// Invalidate specific transaction list
queryClient.invalidateQueries({
  queryKey: queryKeys.transactions.list(userId)
})
```
