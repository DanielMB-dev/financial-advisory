---
name: finance-domain-modeler
description: This skill should be used when modeling financial domain entities (transactions, accounts, categories, budgets) with Supabase and implementing hexagonal architecture patterns. Use this skill when designing database schemas for financial data, implementing domain-driven design for finance applications, creating value objects for money and currencies, modeling complex financial relationships, and ensuring data integrity for financial operations. The skill provides patterns optimized for personal finance management applications.
---

# Finance Domain Modeler

## Overview

Provide comprehensive patterns for modeling financial domain entities in Supabase-based applications using Domain-Driven Design (DDD) principles and hexagonal architecture. Focus on common financial entities like transactions, accounts, categories, and budgets with proper data integrity and business rule enforcement.

## When to Use This Skill

Use this skill when:
- Designing database schemas for financial applications
- Modeling transactions, accounts, and balance tracking
- Implementing multi-currency support
- Creating category and tagging systems
- Building budget and goal tracking features
- Designing recurring transaction patterns
- Implementing account aggregation
- Modeling financial reports and analytics
- Ensuring data consistency for financial operations
- Implementing audit trails for financial data

## Official Documentation References

- **Supabase Database**: https://supabase.com/docs/guides/database
- **PostgreSQL Data Types**: https://www.postgresql.org/docs/current/datatype.html
- **Domain-Driven Design**: https://martinfowler.com/bliki/DomainDrivenDesign.html
- **Money Pattern**: https://martinfowler.com/eaaCatalog/money.html
- **Hexagonal Architecture**: https://alistair.cockburn.us/hexagonal-architecture/

## Core Financial Entities

### 1. Transaction Entity

The fundamental building block for financial tracking:

```sql
-- Database Schema
CREATE TABLE transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  account_id UUID REFERENCES accounts(id),
  category_id UUID NOT NULL REFERENCES categories(id),

  -- Money fields (use DECIMAL to avoid floating-point errors)
  amount DECIMAL(12, 2) NOT NULL CHECK (amount != 0),
  currency VARCHAR(3) DEFAULT 'USD',

  type VARCHAR(20) NOT NULL CHECK (type IN ('income', 'expense', 'transfer')),
  date DATE NOT NULL,
  description TEXT,
  notes TEXT,

  -- Metadata
  tags TEXT[],
  is_recurring BOOLEAN DEFAULT FALSE,
  recurring_rule_id UUID REFERENCES recurring_rules(id),

  -- Soft delete
  deleted_at TIMESTAMP,

  -- Timestamps
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),

  CONSTRAINT valid_currency CHECK (currency ~ '^[A-Z]{3}$')
);

-- Indexes
CREATE INDEX idx_transactions_user_id ON transactions(user_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_transactions_date ON transactions(date DESC) WHERE deleted_at IS NULL;
CREATE INDEX idx_transactions_category ON transactions(category_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_transactions_type ON transactions(type) WHERE deleted_at IS NULL;

-- RLS Policies
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own transactions"
  ON transactions FOR ALL
  USING (auth.uid() = user_id);
```

**TypeScript Domain Entity:**

```typescript
// domain/entities/Transaction.ts
import { Money } from '../value-objects/Money'
import { TransactionType } from '../value-objects/TransactionType'

export interface Transaction {
  id: string
  userId: string
  accountId?: string
  categoryId: string
  amount: Money
  type: TransactionType
  date: Date
  description?: string
  notes?: string
  tags: string[]
  isRecurring: boolean
  recurringRuleId?: string
  deletedAt?: Date
  createdAt: Date
  updatedAt: Date
}

// domain/value-objects/Money.ts
export class Money {
  constructor(
    public readonly amount: number,
    public readonly currency: string = 'USD'
  ) {
    if (amount === 0) throw new Error('Amount cannot be zero')
    if (!this.isValidCurrency(currency)) throw new Error('Invalid currency code')
  }

  private isValidCurrency(currency: string): boolean {
    return /^[A-Z]{3}$/.test(currency)
  }

  add(other: Money): Money {
    if (this.currency !== other.currency) {
      throw new Error('Cannot add money with different currencies')
    }
    return new Money(this.amount + other.amount, this.currency)
  }

  subtract(other: Money): Money {
    if (this.currency !== other.currency) {
      throw new Error('Cannot subtract money with different currencies')
    }
    return new Money(this.amount - other.amount, this.currency)
  }

  format(): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: this.currency
    }).format(this.amount)
  }
}
```

### 2. Account Entity

For tracking different financial accounts:

```sql
CREATE TABLE accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,

  name VARCHAR(255) NOT NULL,
  type VARCHAR(50) NOT NULL CHECK (type IN ('checking', 'savings', 'credit_card', 'investment', 'cash', 'loan')),

  -- Balance tracking
  balance DECIMAL(12, 2) DEFAULT 0,
  currency VARCHAR(3) DEFAULT 'USD',

  -- Account details
  institution VARCHAR(255),
  account_number VARCHAR(255), -- Encrypted in practice
  color VARCHAR(7), -- Hex color for UI
  icon VARCHAR(50),

  is_active BOOLEAN DEFAULT TRUE,
  exclude_from_totals BOOLEAN DEFAULT FALSE,

  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),

  CONSTRAINT positive_balance CHECK (
    type IN ('checking', 'savings', 'investment', 'cash')
    OR balance <= 0
  )
);

CREATE INDEX idx_accounts_user_id ON accounts(user_id) WHERE is_active = TRUE;

ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own accounts"
  ON accounts FOR ALL
  USING (auth.uid() = user_id);
```

### 3. Category Entity

Hierarchical category system:

```sql
CREATE TABLE categories (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  parent_id UUID REFERENCES categories(id),

  name VARCHAR(255) NOT NULL,
  type VARCHAR(20) NOT NULL CHECK (type IN ('income', 'expense', 'both')),
  color VARCHAR(7),
  icon VARCHAR(50),

  -- System vs user categories
  is_system BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,

  -- Ordering
  sort_order INT DEFAULT 0,

  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),

  CONSTRAINT unique_user_category UNIQUE (user_id, name) WHERE user_id IS NOT NULL,
  CONSTRAINT unique_system_category UNIQUE (name) WHERE is_system = TRUE
);

CREATE INDEX idx_categories_user ON categories(user_id) WHERE is_active = TRUE;
CREATE INDEX idx_categories_type ON categories(type) WHERE is_active = TRUE;

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- System categories are readable by all
CREATE POLICY "System categories are public"
  ON categories FOR SELECT
  USING (is_system = TRUE);

-- User categories are private
CREATE POLICY "Users manage own categories"
  ON categories FOR ALL
  USING (user_id = auth.uid());
```

### 4. Budget Entity

Budget tracking and limits:

```sql
CREATE TABLE budgets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  category_id UUID REFERENCES categories(id),

  name VARCHAR(255) NOT NULL,
  amount DECIMAL(12, 2) NOT NULL CHECK (amount > 0),
  currency VARCHAR(3) DEFAULT 'USD',

  period VARCHAR(20) NOT NULL CHECK (period IN ('weekly', 'monthly', 'quarterly', 'yearly')),
  start_date DATE NOT NULL,
  end_date DATE,

  -- Alerts
  alert_threshold DECIMAL(5, 2) DEFAULT 80.00 CHECK (alert_threshold BETWEEN 0 AND 100),
  alert_enabled BOOLEAN DEFAULT TRUE,

  is_active BOOLEAN DEFAULT TRUE,

  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_budgets_user ON budgets(user_id) WHERE is_active = TRUE;
CREATE INDEX idx_budgets_period ON budgets(start_date, end_date) WHERE is_active = TRUE;

ALTER TABLE budgets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own budgets"
  ON budgets FOR ALL
  USING (auth.uid() = user_id);
```

### 5. Recurring Transaction Rules

For automated transaction creation:

```sql
CREATE TABLE recurring_rules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,

  -- Template fields
  account_id UUID REFERENCES accounts(id),
  category_id UUID NOT NULL REFERENCES categories(id),
  amount DECIMAL(12, 2) NOT NULL,
  currency VARCHAR(3) DEFAULT 'USD',
  type VARCHAR(20) NOT NULL CHECK (type IN ('income', 'expense')),
  description TEXT,

  -- Recurrence pattern
  frequency VARCHAR(20) NOT NULL CHECK (frequency IN ('daily', 'weekly', 'monthly', 'yearly')),
  interval INT DEFAULT 1 CHECK (interval > 0),
  start_date DATE NOT NULL,
  end_date DATE,

  -- Day specifications
  day_of_month INT CHECK (day_of_month BETWEEN 1 AND 31),
  day_of_week INT CHECK (day_of_week BETWEEN 0 AND 6),

  last_generated_date DATE,
  next_due_date DATE,

  is_active BOOLEAN DEFAULT TRUE,

  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_recurring_rules_user ON recurring_rules(user_id) WHERE is_active = TRUE;
CREATE INDEX idx_recurring_rules_due ON recurring_rules(next_due_date) WHERE is_active = TRUE;

ALTER TABLE recurring_rules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own recurring rules"
  ON recurring_rules FOR ALL
  USING (auth.uid() = user_id);
```

## Financial Business Rules

### 1. Balance Calculation

Create a function for accurate balance calculation:

```sql
CREATE OR REPLACE FUNCTION calculate_account_balance(account_uuid UUID)
RETURNS DECIMAL AS $$
  SELECT COALESCE(
    SUM(
      CASE
        WHEN type = 'income' THEN amount
        WHEN type = 'expense' THEN -amount
        ELSE 0
      END
    ),
    0
  )
  FROM transactions
  WHERE account_id = account_uuid
    AND deleted_at IS NULL;
$$ LANGUAGE SQL STABLE;
```

### 2. Budget Progress Tracking

```sql
CREATE OR REPLACE FUNCTION calculate_budget_spent(budget_uuid UUID)
RETURNS DECIMAL AS $$
  SELECT COALESCE(SUM(t.amount), 0)
  FROM transactions t
  JOIN budgets b ON b.id = budget_uuid
  WHERE t.user_id = b.user_id
    AND t.category_id = b.category_id
    AND t.type = 'expense'
    AND t.date BETWEEN b.start_date AND COALESCE(b.end_date, CURRENT_DATE)
    AND t.deleted_at IS NULL;
$$ LANGUAGE SQL STABLE;
```

## Data Integrity Patterns

### 1. Audit Trail

Track all changes to financial data:

```sql
CREATE TABLE audit_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  table_name TEXT NOT NULL,
  record_id UUID NOT NULL,
  action TEXT NOT NULL CHECK (action IN ('INSERT', 'UPDATE', 'DELETE')),
  old_data JSONB,
  new_data JSONB,
  user_id UUID REFERENCES auth.users(id),
  timestamp TIMESTAMP DEFAULT NOW()
);

-- Audit trigger function
CREATE OR REPLACE FUNCTION audit_trigger()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    INSERT INTO audit_log (table_name, record_id, action, old_data, user_id)
    VALUES (TG_TABLE_NAME, OLD.id, 'DELETE', to_jsonb(OLD), auth.uid());
    RETURN OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    INSERT INTO audit_log (table_name, record_id, action, old_data, new_data, user_id)
    VALUES (TG_TABLE_NAME, NEW.id, 'UPDATE', to_jsonb(OLD), to_jsonb(NEW), auth.uid());
    RETURN NEW;
  ELSIF TG_OP = 'INSERT' THEN
    INSERT INTO audit_log (table_name, record_id, action, new_data, user_id)
    VALUES (TG_TABLE_NAME, NEW.id, 'INSERT', to_jsonb(NEW), auth.uid());
    RETURN NEW;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Apply to transactions table
CREATE TRIGGER transactions_audit
  AFTER INSERT OR UPDATE OR DELETE ON transactions
  FOR EACH ROW EXECUTE FUNCTION audit_trigger();
```

### 2. Soft Delete with Cleanup

```sql
-- Function to permanently delete old soft-deleted records
CREATE OR REPLACE FUNCTION cleanup_soft_deletes()
RETURNS void AS $$
BEGIN
  DELETE FROM transactions
  WHERE deleted_at < NOW() - INTERVAL '90 days';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

## Resources

### references/

- **financial-entities-guide.md** - Complete entity relationship diagrams and modeling patterns
- **money-handling-best-practices.md** - Patterns for avoiding floating-point errors and currency conversion
- **multi-currency-support.md** - Implementing currency conversion and exchange rates
- **reporting-patterns.md** - Aggregation queries for financial reports and analytics

Load these references when implementing specific financial features or designing complex schemas.

## Best Practices

1. **Always use DECIMAL** for money amounts, never FLOAT or REAL
2. **Implement audit trails** for all financial data changes
3. **Use check constraints** to enforce business rules at database level
4. **Create indexes** on commonly queried fields (user_id, date, type)
5. **Implement soft deletes** for financial data (never hard delete)
6. **Use RLS policies** for multi-tenant data isolation
7. **Validate currency codes** with CHECK constraints
8. **Store dates as DATE type** for financial records
9. **Use UUIDs** for all primary keys
10. **Implement balance caching** with triggers for performance
