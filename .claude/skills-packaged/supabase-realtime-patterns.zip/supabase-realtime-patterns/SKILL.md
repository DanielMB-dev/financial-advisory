---
name: supabase-realtime-patterns
description: This skill should be used when implementing real-time data synchronization with Supabase Realtime for financial applications. Use this skill when setting up live database subscriptions, implementing real-time updates for transactions and balances, handling presence features, managing broadcast channels, and optimizing real-time performance. The skill provides patterns specifically for financial data streams where immediate updates are critical for user experience.
---

# Supabase Realtime Patterns

## Overview

Provide patterns for implementing Supabase Realtime features in financial applications, focusing on real-time data synchronization, optimistic updates, and efficient state management for live financial data.

## When to Use This Skill

Use this skill when:
- Implementing live transaction updates
- Building real-time balance displays
- Creating collaborative budgeting features
- Implementing notification systems
- Building live dashboards with streaming data
- Synchronizing data across multiple devices
- Implementing presence features (who's online)
- Broadcasting updates to multiple clients

## Official Documentation References

- **Supabase Realtime Overview**: https://supabase.com/docs/guides/realtime
- **Realtime Subscriptions**: https://supabase.com/docs/guides/realtime/postgres-changes
- **Realtime Broadcast**: https://supabase.com/docs/guides/realtime/broadcast
- **Realtime Presence**: https://supabase.com/docs/guides/realtime/presence
- **Performance & Limits**: https://supabase.com/docs/guides/realtime/quotas

## Core Patterns

### 1. Database Changes Subscription

```typescript
'use client'
import { createClient } from '@/lib/supabase/client'
import { useEffect, useState } from 'react'

export function useRealtimeTransactions(userId: string) {
  const [transactions, setTransactions] = useState([])
  const supabase = createClient()

  useEffect(() => {
    const channel = supabase
      .channel('transactions-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${userId}`
        },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            setTransactions(prev => [...prev, payload.new])
          } else if (payload.eventType === 'UPDATE') {
            setTransactions(prev =>
              prev.map(t => t.id === payload.new.id ? payload.new : t)
            )
          } else if (payload.eventType === 'DELETE') {
            setTransactions(prev =>
              prev.filter(t => t.id !== payload.old.id)
            )
          }
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [userId])

  return transactions
}
```

### 2. Broadcast for User Actions

```typescript
// Broadcasting balance updates
const channel = supabase.channel('balance-updates')

// Send update
await channel.send({
  type: 'broadcast',
  event: 'balance-changed',
  payload: { userId, newBalance: 1500.50 }
})

// Receive updates
channel.on('broadcast', { event: 'balance-changed' }, (payload) => {
  console.log('Balance updated:', payload)
})
```

### 3. Presence for Collaborative Features

```typescript
const channel = supabase.channel('budget-room', {
  config: { presence: { key: userId } }
})

// Track who's editing
channel.on('presence', { event: 'sync' }, () => {
  const state = channel.presenceState()
  console.log('Users online:', Object.keys(state))
})

channel.subscribe(async (status) => {
  if (status === 'SUBSCRIBED') {
    await channel.track({ user: userId, editing: 'budget' })
  }
})
```

## Best Practices

1. **Always clean up subscriptions** in useEffect cleanup
2. **Filter subscriptions** to reduce unnecessary updates
3. **Use RLS policies** - Realtime respects RLS
4. **Implement optimistic updates** for better UX
5. **Handle reconnection** gracefully
6. **Batch updates** to reduce state thrashing
7. **Monitor channel quotas** in production
8. **Use broadcast for non-persistent data**
9. **Test with multiple clients** for race conditions
10. **Implement proper error handling** for subscription failures

## Resources

See `references/realtime-examples.md` for complete implementations of real-time patterns for financial dashboards, collaborative budgets, and live notifications.
