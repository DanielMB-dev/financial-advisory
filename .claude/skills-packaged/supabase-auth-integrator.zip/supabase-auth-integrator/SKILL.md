---
name: supabase-auth-integrator
description: This skill should be used when integrating Supabase Auth with Next.js applications, implementing JWT session management, configuring authentication flows (login, signup, logout, password reset), setting up middleware for protected routes, and following Supabase authentication best practices. The skill provides patterns for server-side and client-side auth, cookie-based session handling with @supabase/ssr, and secure token management.
---

# Supabase Auth Integrator

## Overview

Provide comprehensive guidance for integrating Supabase Authentication into Next.js applications with proper session management, security best practices, and modern authentication patterns. Cover both client-side and server-side authentication flows, JWT token handling, and middleware configuration for protected routes.

## When to Use This Skill

Use this skill when:
- Setting up Supabase Auth for the first time in a Next.js project
- Implementing authentication flows (signup, login, logout, password reset)
- Configuring protected routes with Next.js middleware
- Managing JWT sessions with cookie-based storage
- Implementing OAuth providers (Google, GitHub, etc.)
- Setting up email verification and magic links
- Troubleshooting authentication issues
- Migrating from NextAuth.js to Supabase Auth

## Official Documentation References

Refer to these official documentation sources while implementing:

- **Supabase Auth Overview**: https://supabase.com/docs/guides/auth
- **Supabase Auth with Next.js**: https://supabase.com/docs/guides/auth/server-side/nextjs
- **Supabase Auth Helpers (@supabase/ssr)**: https://supabase.com/docs/guides/auth/server-side/overview
- **Supabase Auth Hooks**: https://supabase.com/docs/guides/auth/auth-hooks
- **JWT and Sessions**: https://supabase.com/docs/guides/auth/sessions
- **Row Level Security**: https://supabase.com/docs/guides/auth/row-level-security
- **Next.js Middleware**: https://nextjs.org/docs/app/building-your-application/routing/middleware

## Implementation Guide

### 1. Installation and Setup

Install the required Supabase packages:

```bash
npm install @supabase/supabase-js @supabase/ssr
```

Configure environment variables in `.env.local`:

```bash
NEXT_PUBLIC_SUPABASE_URL=your-project-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

### 2. Supabase Client Configuration

Create Supabase clients for different contexts. Refer to `references/supabase-clients.md` for detailed implementation patterns.

**Key Points:**
- Use **Server Component client** for server-side data fetching
- Use **Server Action client** for mutations and form submissions
- Use **Middleware client** for route protection
- Use **Browser client** for client-side interactions

### 3. Authentication Flows

Implement authentication flows following the patterns in `references/auth-flows.md`.

**Core Flows:**
- **Sign Up**: Email/password registration with email verification
- **Sign In**: Email/password, magic link, or OAuth
- **Sign Out**: Proper session cleanup
- **Password Reset**: Email-based password recovery
- **Email Verification**: Confirm email addresses
- **OAuth Providers**: Google, GitHub, Azure, etc.

### 4. Protected Routes with Middleware

Configure Next.js middleware for route protection as shown in `references/middleware-patterns.md`.

**Protection Strategy:**
- Define public routes (login, signup)
- Define protected routes (dashboard, profile)
- Redirect unauthenticated users to login
- Refresh tokens automatically

### 5. Session Management

Implement secure session management with cookie-based storage:

**Best Practices:**
- Store sessions in HTTP-only cookies
- Use `@supabase/ssr` for server-side session handling
- Refresh tokens before expiration
- Handle token refresh errors gracefully
- Clear sessions on logout

### 6. Security Considerations

Follow security best practices:

- **Never expose service role key** in client-side code
- **Use anon key** for client-side operations
- **Implement RLS policies** on all user tables
- **Validate sessions** on every protected route
- **Use HTTPS** in production
- **Set secure cookie options** (httpOnly, secure, sameSite)
- **Implement rate limiting** on auth endpoints
- **Log authentication events** for audit trails

## Resources

### references/

This skill includes reference documentation to support implementation:

- **supabase-clients.md** - Detailed patterns for creating Supabase clients in different Next.js contexts (Server Components, Server Actions, Middleware, Client Components)
- **auth-flows.md** - Complete implementation examples for all authentication flows (signup, login, logout, password reset, OAuth)
- **middleware-patterns.md** - Next.js middleware configuration for protecting routes and managing sessions
- **troubleshooting.md** - Common authentication issues and their solutions

Load these references as needed when implementing specific features. They contain detailed code examples, best practices, and edge case handling.

## Best Practices Summary

1. **Always use server-side rendering** for initial user data
2. **Implement proper error handling** for all auth operations
3. **Use TypeScript** for type safety with Supabase types
4. **Test authentication flows** thoroughly
5. **Monitor authentication events** in production
6. **Keep Supabase packages updated** for security patches
7. **Use environment variables** for configuration
8. **Implement proper loading states** during auth operations
9. **Handle edge cases** (expired sessions, network errors)
10. **Document authentication architecture** for team
